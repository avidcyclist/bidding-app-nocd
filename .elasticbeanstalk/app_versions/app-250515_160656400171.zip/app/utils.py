import boto3
from flask import current_app
import os
from twilio.rest import Client

def get_s3_client():
    """
    Returns a boto3 S3 client. If running on AWS (Elastic Beanstalk), it will use the IAM Role.
    """
    return boto3.client(
        's3',
        aws_access_key_id=current_app.config.get('S3_ACCESS_KEY'),
        aws_secret_access_key=current_app.config.get('S3_SECRET_KEY')
    )

def send_sms(to, message):
    account_sid = os.environ.get("TWILIO_ACCOUNT_SID")
    auth_token = os.environ.get("TWILIO_AUTH_TOKEN")
    twilio_number = os.environ.get("TWILIO_PHONE_NUMBER")

    client = Client(account_sid, auth_token)
    try:
        message = client.messages.create(
            body=message,
            from_=twilio_number,
            to=to
        )
        print(f"SMS sent successfully: {message.sid}")
    except Exception as e:
        print(f"Failed to send SMS to {to}: {str(e)}")