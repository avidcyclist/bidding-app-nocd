import boto3
from flask import current_app

def get_s3_client():
    """
    Returns a boto3 S3 client. If running on AWS (Elastic Beanstalk), it will use the IAM Role.
    """
    return boto3.client(
        's3',
        aws_access_key_id=current_app.config.get('S3_ACCESS_KEY'),
        aws_secret_access_key=current_app.config.get('S3_SECRET_KEY')
    )