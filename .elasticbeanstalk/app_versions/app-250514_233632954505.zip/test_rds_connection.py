# filepath: c:\Users\Mitch\Desktop\bidding-app-nocd\test_rds_connection.py
import mysql.connector


"""
try:
    connection = mysql.connector.connect(
        host="bidding-app-db.cctaq8qo0d28.us-east-1.rds.amazonaws.com",  # Replace with your RDS endpoint
        user="admin",  # Replace with your RDS username
        password="6hSKg4q3viqfmOxnw7ae"  # Replace with your RDS password
    )
    cursor = connection.cursor()
    cursor.execute("CREATE DATABASE bidding_app;")
    print("Database 'bidding_app' created successfully!")
except Exception as e:
    print(f"Error: {e}")
finally:
    if 'connection' in locals() and connection.is_connected():
        cursor.close()
        connection.close()
        
"""

try:
    connection = mysql.connector.connect(
        host="bidding-app-db.cctaq8qo0d28.us-east-1.rds.amazonaws.com",  # Your RDS endpoint
        user="admin",  # Your RDS username
        password="6hSKg4q3viqfmOxnw7ae",  # Your RDS password
        database="bidding_app"  # Your database name
    )
    if connection.is_connected():
        print("Connected to AWS RDS MySQL database!")
except Exception as e:
    print(f"Error: {e}")
finally:
    if 'connection' in locals() and connection.is_connected():
        connection.close()